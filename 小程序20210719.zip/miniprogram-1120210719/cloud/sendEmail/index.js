
const cloud = require('wx-server-sdk')
 
cloud.init({
  traceUser: true,
  env: 'wx1c875541493fc5fd'
})
 
var db = cloud.database()
//引入发送邮件的类库
var nodemailer = require('nodemailer')
// 创建一个SMTP客户端配置
var config = {
  host: 'smtp.qq.com', //网易163邮箱 smtp.163.com
  port: 465, //网易邮箱端口 25
  auth: {
    user: '838618033@qq.com', //邮箱账号
    pass: 'befoglzjsndqbbgg' //邮箱的授权码
  }
};
// 创建一个SMTP客户端对象
var transporter = nodemailer.createTransport(config);
// 云函数入口函数
exports.main = async(event, context) => {
const db = cloud.database()    //链接数据库
  // 创建一个邮件对象
  var mail = {
    // 发件人
    from: '来自小程序管理员 <838618033@qq.com>',
    // 主题
    subject: '【承德奔驰一点通小程序】用户操作提醒',
    // 收件人
    to: '838618033@qq.com,410730889@qq.com,346215890@qq.com',//'838618033@qq.com,410730889@qq.com,346215890@qq.com'
    // text:'姓名为曹博信的车主拨打了维修厂的电话'
    // 邮件内容，text或者html格式
    text:event.text
  };

  let res = await transporter.sendMail(mail);
  return res;
}

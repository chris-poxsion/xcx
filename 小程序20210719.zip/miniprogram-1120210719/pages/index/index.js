

Page({
 
  data: {
    text:null
  },
  onLoad: function (options) {
  },


  handleTextarea(e) {
    this.setData({
      toTextArea: e.detail.value
    })
  },
  handlechose(e) {
    this.setData({
      tochoseArea: e.detail.value
    })
  },

  sendEmail(e){
    const{tochoseArea}=this.data
    const{toTextArea}=this.data 
    if (toTextArea.length <11&& tochoseArea.value =="") {
      wx.navigateTo({
        url: 'index',
      })
      }else{
    wx.cloud.callFunction({
      name:"sendEmail",
      data:{
      text:'手机号码为'+toTextArea+'的车主有拨打全国报险电话的意图，请尽快联系！'
      
      },
      success(res){
        console.log("发送成功",res)
      },
      fail(res){
        console.log("发送失败",res)
      }
    })}
  },
  sendEmailto4s1(e){
    const{tochoseArea}=this.data
    const{toTextArea}=this.data 
    if (toTextArea.length <11&& tochoseArea.value =="") {
      wx.navigateTo({
        url: 'index',
      })
      }else{
    wx.cloud.callFunction({
      name:"sendEmail",
      data:{
      text:'手机号码为'+toTextArea+'的车主可能遇到了功能故障，有联系4S店的意图，请尽快联系！'
      
      },
      success(res){
        console.log("发送成功",res)
      },
      fail(res){
        console.log("发送失败",res)
      }
    })}
  },
  sendEmailto4s2(e){
    const{tochoseArea}=this.data
    const{toTextArea}=this.data 
    if (toTextArea.length <11&& tochoseArea.value =="") {
      wx.navigateTo({
        url: 'index',
      })
      }else{
    wx.cloud.callFunction({
      name:"sendEmail",
      data:{
      text:'手机号码为'+toTextArea+'的车主有想获得报险技巧的意图，请尽快联系！'
      
      },
      success(res){
        console.log("发送成功",res)
      },
      fail(res){
        console.log("发送失败",res)
      }
    })}
  },

  formSubmit: function (e) {
    // wx.redirectTo({
    //   url: '/pages/4s/4s',
    // })
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var data=e.detail.value
    if (e.detail.value.userName.length <11 ||e.detail.value.sex =='') {
      wx.navigateTo({
        url: 'index',
      })
      wx.showToast({
      title: '请您补全信息！',
      icon: 'loading',
      duration: 5000,
      })      
      }else{
        wx.showLoading({
          title: '数据正在提交中......',
          mask:"true"
        })
        if (e.detail.value.sex =='选择维修店修车'){
          wx.redirectTo({
          url: '/pages/wxc/wxc',
        })
        }else{if(e.detail.value.sex == "选择4S店修车"){
          wx.redirectTo({
            url: '/pages/4s/4s',
          })
        }else{
          if(e.detail.value.sex == "选择获取技巧"){
            wx.redirectTo({

              url: '/pages/jiqiao/jiqiao',
            })
          }
        }
        }

  
        const db = wx.cloud.database()
        db.collection('database2021720').add({
        data: data,
        success: res => {
          // 在返回结果中会包含新创建的记录的 _id
          this.setData({
            counterId: res._id
          })
          wx.showToast({
            title: '请您拨打电话',
          })
          wx.hideLoading()
         console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '新增记录失败'
          })
          console.error('[数据库] [新增记录] 失败：', err)
        }
      })
    }
    // if(e.detail.value.sex =='选择4S店修车'){

    // }
  },

})
